
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pembayaran SPP</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo"><a href="index.html" class="h2 mb-0">Bayar Yukk<span class="text-primary">.</span> </a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#index.php" class="nav-link">Home</a></li>
                <li><a href="siswa.php" class="nav-link">Siswa</a></li>
                <li><a href="#team-section" class="nav-link">Kelas</a></li>
                <li><a href="#services-section" class="nav-link">Pembayaran</a></li>
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>
      
    </header>
    <section class="site-section bg-light" id="contact-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center">
            <h2 class="section-title mb-3">Form Siswa</h2>
          </div>
        </div>
        <?php
	  			include 'koneksi.php';
			  	if (isset($_POST['submit'])) {
				$id_pembayaran= $_POST['id_pembayaran'];
				$id_petugas= $_POST['id_petugas'];
				$nis= $_POST['nis'];
        $tgl_bayar= $_POST['tgl_bayar'];
        $jumlah_bayar= $_POST['jumlah_bayar'];
        $input = mysqli_query($conn, "INSERT INTO tabel_pembayaran(id_pembayaran,id_petugas,nis,tgl_bayar,jumlah_bayar) VALUES('$id_pembayaran','$id_petugas','$nis','$tgl_bayar','$jumlah_bayar')");
				'header("location: pembayaran.php")';
}
				?>
        <div class="row">
          <div class="col-md-7 mb-5">
            <form action="" method="post" class="p-5 bg-white">
              
              <h2 class="h4 text-black mb-5">Contact Form</h2> 

              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">Id Pembayaran</label>
                  <input type="text" id="id_pembayaran" name="id_pembayaran" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Id Petugas</label>
                  <input type="text" id="id_petugas" name="id_petugas" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">NIS</label>
                  <input type="text" id="nis" name="nis" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Tanggal Bayar</label>
                  <input type="date" id="tgl_bayar" name="tgl_bayar" class="form-control">
                </div>
              </div>
              <div class="col-md-6">
                  <label class="text-black" for="lname">Jumlah Bayar</label>
                  <input type="text" id="jumlah_bayar" name="jumlah_bayar" class="form-control">
                </div>
              </div>
                <div class="col-md-12">
                  <input type="submit" value="Simpan" name="submit" class="btn btn-primary btn-md text-white">
                </div> 
              </div>
              <a href="datapembayaran.php" class="btn btn-link mb-1">Lihat Pengaduan Lainnya</a>  
            </form>
          </div>
          <div class="col-md-5">
            
          </div>
        </div>
      </div>
    </section>

  </div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>