<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Pointer &mdash; Website by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-6 col-xl-2">
            <h1 class="mb-0 site-logo"><a href="admin.php" class="h2 mb-0">Bayar Yukk<span class="text-primary">.</span> </a></h1>
          </div>

          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="datapembayaran.php" class="nav-link">Tabel Pembayaran</a></li>
                <li><a href="datakelas.php" class="nav-link">Tabel Kelas</a></li>
                <li><a href="datasiswa.php" class="nav-link">Tabel Siswa</a></li>
                <li><a href="logout.php" class="nav-link">LogOut</a></li>
              </ul>
            </nav>
          </div>


          <div class="col-6 d-inline-block d-xl-none ml-md-0 py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a></div>

        </div>
      </div>
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center">
            <h3 class="section-sub-title">Pembayaran SPP</h3>
          </div>
        </div>
      
        <div class="row justify-content-center">
			<div class="col-18">
			<form class="form-inline mt-5 mx-auto justify-content-center" action="petugas.php" method="post">
				<label class="my-1 mr-3 ml-4" for="inlineFormCustomSelectPref">cari berdasarkan</label>
				<select class="custom-select my-1 mr-sm-3 w-25" id="inlineFormCustomSelectPref" name="pilih">
					<option select>choose..</option>
					<option value="id_pengaduan">id pengaduan</option>
					<option value="nik">nik</option>
					<option value="tgl_pengaduan">tanggal pengaduan</option>
					<option value="isi_laporan">isi laporan</option>
				</select>
				<input type="text" name="textcari" class="form-control mr-3 w-25">

				<button type="submit" name="cari" class="btn btn-primary py-3 px-4">cari</button>
                
				<a href="pengaduan.php" class="btn btn-link">tampilkan semua</a>

			</form>
			<table class="table table-bordered bg-light mt-5">
				<thead class="thead-dark text-center">
					<tr>
						<th scope="col">no</th>
						<th scope="col">id pengaduan</th>
						<th scope="col">NIK</th>
						<th scope="col">tgl pengaduan</th>
						<th scope="col">isi laporan</th>
						<th scope="col">aksi</th>
					</tr>
				</thead>
			<?php
			include 'koneksi.php';
			$input="";
			if (isset($_POST["cari"])){
				$opsi=$_POST["pilih"];
				$nama=$_POST["textcari"];
				$input=mysqli_query($conn, "SELECT * from pengaduan WHERE $opsi like '%$nama%'");	
				}else{
					$input=mysqli_query($conn, "SELECT * from pengaduan");
			}

            $no = 1;
            foreach ($input as $row){
                echo "<tr>
                    <td>$no</td>
                    <td>" . $row['id_pengaduan'] . "</td>
                    <td>" . $row['nik'] . "</td>
					<td>" . $row['tgl_pengaduan'] . "</td>
					<td>" . $row['isi_laporan'] . "</td>
                    <td>
					<a href='tanggapan.php?id_pengaduan=$row[id_pengaduan]'>
					<input type='button' class='btn btn-secondary py-3 px-4'
					value='tanggapi'></a>
					</td></tr>";

                     $no++;
                 }
?>
</table>
			</tbody>
			
			</div>
		</div>

        
    </header>
</body>
</html>