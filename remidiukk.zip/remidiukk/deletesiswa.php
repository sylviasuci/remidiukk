<?php
include 'koneksi.php';
$nis = $_GET['nis'];
$query = "delete from tabel_siswa where nis='$nis'";
mysqli_query($conn, $query);
header("location:datasiswa.php");
?>