<?php
$server = "localhost";
$username = "root";
$password = "";
$db = "remidiukk";

$conn = new mysqli
("$server","$username","$password","$db");
?>
